# Dataset

The experiment uses `corpus_features.csv` from the Zenodo record:

Cross-model evaluation of phishing detectors against LLM-generated emails:
dataset, code and results.

Zenodo DOI: 10.5281/zenodo.20250116

For this submission bundle, the dataset is not duplicated in the GitHub-ready
folder. Place `corpus_features.csv` in this directory before running the code.

Expected path:
`data/corpus_features.csv`

The dataset repository states that the data are released under CC BY 4.0;
retain the required attribution when redistributing it.
